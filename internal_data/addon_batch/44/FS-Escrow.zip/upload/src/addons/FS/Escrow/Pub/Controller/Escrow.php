<?php

namespace FS\Escrow\Pub\Controller;

use XF\Mvc\ParameterBag;
use XF\Pub\Controller\AbstractController;
use XF\Mvc\RouteMatch;

class Escrow extends AbstractController
{
    public function actionIndex(ParameterBag $params){
        $rules = [];
        $rules[] = [
            'message' =>\XF::phrase('fs_escrow_rules'),
            "display_image" => "avatar",
            "display_style" => "primary",
            
        ];
        $viewpParams = [
            'rules'=>$rules
        ];

      
        return $this->view('FS\Escrow', 'fs_escrow_landing', $viewpParams);
    
    }

    public function actionAdd(ParameterBag $params){
        $viewpParams = [];
        return $this->view('FS\Escrow', 'fs_escrow_addEdit', $viewpParams);
    
    }

    public function actionDeposit(ParameterBag $params){
        $viewpParams = [];
        return $this->view('FS\Escrow', 'fs_escrow_deposit', $viewpParams);
    
    }

}