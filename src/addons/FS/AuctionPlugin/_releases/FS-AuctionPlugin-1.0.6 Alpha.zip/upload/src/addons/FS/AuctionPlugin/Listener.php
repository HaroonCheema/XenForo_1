<?php

namespace FS\AuctionPlugin;

use XF\Util\Arr;

class Listener
{


    public static function addonPostInstall(\XF\AddOn\AddOn $addOn, \XF\Entity\AddOn $installedAddOn, array $json, array &$stateChanges)
    {
        
    }
}
