<?php

namespace FS\AuctionPlugin;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;

use XF\Db\Schema\Alter;
use XF\Db\Schema\Create;

class Setup extends AbstractSetup
{
	use StepRunnerInstallTrait;
	use StepRunnerUpgradeTrait;
	use StepRunnerUninstallTrait;

	public function installstep1()
	{
		$this->schemaManager()->createTable('fs_auction_ship_terms', function (Create $table) {
			$table->addColumn('term_id', 'int', '255')->autoIncrement();
			$table->addColumn('shipping_term', 'mediumtext')->nullable();

			$table->addPrimaryKey('term_id');
		});

		$this->schemaManager()->createTable('fs_auction_ship_via', function (Create $table) {
			$table->addColumn('via_id', 'int', '255')->autoIncrement();
			$table->addColumn('ship_via', 'mediumtext')->nullable();

			$table->addPrimaryKey('via_id');
		});
	}

	public function uninstallStep1()
	{
		$sm = $this->schemaManager();
		$sm->dropTable('fs_auction_ship_terms');
		$sm->dropTable('fs_auction_ship_via');
	}
}
