<?php

namespace FS\UpgradeUserGroup\Cron;


class UpgradeUserGroupCron
{

    public static function upgradeUsergroup()
    {
        $finder = \XF::finder('FS\UpgradeUserGroup:UpgradeUserGroup')->where('last_login', null)->fetch();

        foreach ($finder as $value) {
            $conditions = [
                ['user_group_id', $value->current_userGroup],
                ['secondary_group_ids', 'LIKE', '%' . $value->current_userGroup . '%'],
            ];

            $finderUsergroup = \XF::finder('XF:User')->where('user_group_id', '!=', $value->upgrade_userGroup)->where('secondary_group_ids', 'NOT LIKE', '%' . $value->upgrade_userGroup . '%')->where('message_count', '>=', $value->message_count)->whereOr($conditions)->fetch();

            foreach ($finderUsergroup as $user) {
                $userGroupIds = $user->secondary_group_ids;
                array_push($userGroupIds, $value->upgrade_userGroup);
                $user->fastUpdate('secondary_group_ids', $userGroupIds);
            }
        }
    }

    public static function downgradeUsergroup()
    {
        $finder = \XF::finder('FS\UpgradeUserGroup:UpgradeUserGroup')->where('message_count', null)->fetch();

        foreach ($finder as $value) {
            $conditions = [
                ['user_group_id', $value->current_userGroup],
                ['secondary_group_ids', 'LIKE', '%' . $value->current_userGroup . '%'],
            ];

            $finderUsergroup = \XF::finder('XF:User')->where('secondary_group_ids', 'LIKE', '%' . $value->upgrade_userGroup . '%')->where('last_activity', '<=', time() - ($value->last_login * 86400))->whereOr($conditions)->getQuery();

            foreach ($finderUsergroup as $user) {
                $userGroupIds = $user->secondary_group_ids;

                $new_userGroups = array_diff($userGroupIds, array($value->upgrade_userGroup));

                $user->fastUpdate('secondary_group_ids', $new_userGroups);
            }
        }
    }
}
