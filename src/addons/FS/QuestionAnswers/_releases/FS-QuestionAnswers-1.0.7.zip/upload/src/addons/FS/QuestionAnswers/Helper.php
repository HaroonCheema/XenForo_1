<?php

namespace FS\QuestionAnswers;
use XF\Entity\User;

class Helper 
{

}